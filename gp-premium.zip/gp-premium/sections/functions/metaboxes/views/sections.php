<?php
// No direct access, please
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="generate_sections_control">
	
	<noscript>
		<?php _e('Javascript must be enabled to use Generate Sections', 'gp-premium' );?>
	</noscript>
    
	<div id="generate_sections_container"></div>
	
</div>